Data Device Corporation
BU-6908[4/5]S0
ACE Menu for Windows

'README'

--------
OVERVIEW
--------

The ACE Menu for Windows provides a Graphical User Interface (GUI) to 
the ACE series of board level products running on Microsoft's 32-bit 
operating systems (Windows 9x/ME/NT/2000/XP).

The Ace Menu includes support for the 3 different modes of MIL-STD-1553 
communication: Bus Controller, Remote Terminal, and Monitor Terminal. 

DDC is dedicated to providing a powerful, software interface for our 
ACE family of MIL-STD-1553 cards.  Any and all comments or suggestions 
concerning this application are greatly appreciated and should be 
directed to Data Device Corporation 800-DDC-1772 or 631-567-5600 
(Extension 7234), by fax 631-567-7358 (Attention: Data Bus Applications) 
or through the internet at www.ddc-web.com.

------
README
------

This README contains important information about the ACE Menu.
Please refer to this document as a quick guide to the files included 
with this distribution and any changes from previous versions.

-------------------
VERSION INFORMATION
-------------------

DDC versioning mask is defined as X.Y.Z.  'X' is the major revison and
denotes a major change in design and functionality.  'Y' is the minor
revision and denotes an update or added functionality.  'Z' is the
engineering release number and is only present on non-validated 
packages.  Please note that if the version of this package has a 'Z'
digit other than '0' (or not present), it is deemed an 'Engineering
Release' and has not passed DDC's internal software validation.

----------------
REVISION HISTORY
----------------

For up-to-date revision history, please see 'versions.txt', found in
the selected installation folder.

---------------------
ACE MENU INSTALLATION
---------------------

The ACE Menu comes on 2 disks with a Windows installation program.
By default the application will be installed to the ACEMENU
subdirectory as is shown in the following file map:

"\Program Files"
   "\Data Device Corp"
        \ACEMENU
          
Directory of \ACEMENU

     This subdirectory contains the uninstall info.

Uninst.isu	file used by uninstall to remove ACE Menu.
Acemenu.exe	The executable file.
Acemenu.hlp	The help file for the menu.
Acemenu.cnt	The help file contents file.
Readme.txt	This file.


*The DDC 1553 Card Manager (located in the Window Control Panel) must 
have cards configured with a logical device number before you "Set Card 
Configuration" in the menu. 

------------------------------------------------
NOTES FOR HARDWARE INSTALLATION - WIN9x/2000/XP
------------------------------------------------
******PCMCIA/PCI INSTALLATION*******
1) For Windows 9x/2000/XP, if the hardware to be installed is a 
BU-6555x card, the Windows PCMCIA support must be enabled (this 
is an installation option for the OS).  Insert the PC Card into 
the system, or boot with the PCI card installed.  A dialog box
similar to the following should appear:

New Hardware Found

  ILC DATA DEVICE CORPORATION BU-6555xM2-300        or
  ILC DATA DEVICE CORPORATION BU-65549M2-300

Windows 9x/2000/XP will first check to see if it has a default 
driver for the card.  Since there is no Windows default driver you 
will be prompted to supply a driver on a disk, install the card 
with no driver or select a driver from alternate devices.  The 
dialog box will indicate the following:

  Select which driver you want to install for you new hardware:

  * Driver from disk provided by hardware manufacturer.
    Do Not Install a driver
    Select from a list of alternate drivers

Select the radio buttion that will "load the driver from the disk
provided by the harware manufacturer".  Next you are prompted for
the disk.  The ACE Product Driver disk should be inserted into the 
drive and the OK button pressed.

Windows will read the information on the driver disk and install
the appropriate driver.

2) The DDC 1553 Card Manager Control Panel Applet must now be run 
so that a Logical Device Number can be associated with the installed 
card.  Click on the "Start" button, "Settings", and then "Control Panel".
Inside the "Control Panel" double click on the "DDC 1553 Card Manager" 
Icon.  This will display all ACE cards installed on your system.  Simply 
double click on the one you wish to run and choose a logical device 
number for the card (0-31).  The logical device number must be the same as 
the number set in the "Set Card Configuration" dialog inside the ACE Menu 
to access that particular card.  Once this is done a quick selftest can be 
performed on the card by entering the test mode pull down menu and 
selecting card test.

******BU-65539 ISA CARD INSTALLATION*******
1) For Windows 9x/2000/XP, if the hardware to be installed is a BU-65539
ISA card, you should power down the computer and install the card into 
the system taking note of the DIP switch settings.  The DIP switch 
configures the IO Port address for the Control Register.  After making 
sure the card in properly seated in the 16-bit ISA slot power the 
computer and follow these instructions:

	a) Click on the "Start" button, "Settings", and then "Control 
	Panel".  From the "Control Panel" double click on the "Add New
	Hardware" wizard.  Click on "NO" when asked if your would like
	to have Windows 9x/2000/XP search for your hardware.  Click on 
	"Other devices" when asked what hardware you would like to 
	install.  At the next screen click on the button "Have Disk" and 
	browse for the ACE Product Driver Disk (should be in A:).  Click 
	"OK" and you should now have a listing of all the Ace Devices 
	you 	can install.  Select the one that says BU-65539 and then 
	click "Next".  Click "Finish" to finish installing your hardware.

	b) Once you reboot your computer you must make sure that the 
	IO Port Address configured using the DIP switches on your card
	matches the settings Windows 9x/2000/XP has allocated.  The default
	for the BU-65539 card is (0x360).  Right click on the "My Computer"
	icon on the desktop and then click "Properties".  From "Device
	Manager" click on MIL-STD-1553 and then double click on the 
	BU-65539 device.  The properties for the device should be displayed.
	Click on Resources and and double click on "Input/Output Range".
	Scroll through the different setting until you find 0x360 and 
	then click "OK".  Reboot your computer.

	c) You can now run the DDC 1553 Card Manager, found in the Control 
	Panel to associate a logical device number with your BU-65539 card. 
	Do this by double clicking on the device in the Manager listing and 
	choosing a number.  You can now check that the device is working 
	properly by setting the "Set Card Configuration" and running the 
	tests.

------------------------------------------
NOTES FOR HARDWARE INSTALLATION - WINNT
------------------------------------------
******PCMCIA INSTALLATION FOR NT*******
1)Install the software package for Windows NT.  If you like, you could 
set the card type you're working with to start automatically, this will 
save you from starting the driver each time you reboot.  The DDC 1553 
Card Manager will aid you in configuring all non-plug-and-play devices.
Then you can assign a logical device number for the card by clicking the 
"Modify" button.

2) Reboot the the computer making sure that the PCMCIA card is inserted 
BEFORE bootup.  When booted the driver for the PCMCIA card should be 
running.  If it is not running, try starting the PC Card driver by clicking 
"Drivers" in the DDC 1553 Card Manager, selecting the Ace or T/S PCMCIA 
Driver, and clicking "Start".  If an error occurs and the driver can not 
start the most likely cause is a resource conflict.  At this point, you must 
click the PCMCIA card you are running in the list of devices and then click 
the "Modify" button.  Change the resource settings for the card and reboot 
(leaving the card inserted).  Repeat this process until the driver is able 
to start.  Once the driver is started the card should be able to run.

******ISA INSTALLATION FOR NT******
1)Install the BU-65539 card into the computer as specified by the manual.

2)Install the software package for Windows NT and setthe AceIsa Driver to 
be started automatically.  Once you reboot, you should be able to add the 
ISA card to your device list.  Make sure you not the DIP switch settings, 
for that is the I/O of the card.  Once the card is configured, you can 
assign a logical device number for the card by clicking the "Modify" button.
Reboot.

3) Once the computer has been rebooted the driver should be running, if 
it is not there is most likely a resource conflict.  This conflict is 
probably due to the 64K byte memory window needed by the card.  Make sure 
that one of the following memory windows is free (C0000-CFFFF, D0000-DFFFF,
 or E0000-EFFFF).

******PCI INSTALLATION FOR NT******
1)Install the BU-65549 card into the computer as specified by the manual.

2)Install the software package for Windows NT and set the AcePci Driver 
to start automatically.  The BU-65549 card is Plug-and-Play in Windows NT,
 as long as the Driver is started and a card os present.  Once the card is 
 in the device list you can assign a logical device number for the card by 
 clicking the "Modify" button.

3) Once the computer has been rebooted the driver should be running and 
the card ready to be used.

--------------------
Questions? Comments?
--------------------

Please direct any questions or comments about this software 
to our Databus applications department in Bohemia NY.

Data Device Corporation
105 Wilbur Place
Bohemia, NY 11716
(631) 567-5600 x7234
www.ddc-web.com

